package com.example.keymapper;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

public class PickActivity extends Activity {
    int keyCode;
    float px = -1, py = -1;

    class V extends View {
        Paint p = new Paint();
        V(Context c) { super(c); p.setAntiAlias(true); p.setTextSize(48); }
        @Override protected void onDraw(Canvas c) {
            c.drawColor(Color.parseColor("#222222"));
            p.setColor(Color.WHITE);
            c.drawText("Tusa basinca dokunulacak yere parmagini koy ve birak", 60, 100, p);
            c.drawText("Tus: " + KeyEvent.keyCodeToString(keyCode), 60, 170, p);
            if (px >= 0) {
                p.setColor(Color.RED);
                c.drawCircle(px, py, 40, p);
            }
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            px = e.getRawX(); py = e.getRawY();
            invalidate();
            if (e.getAction() == MotionEvent.ACTION_UP) {
                Store.put(PickActivity.this, keyCode, px, py);
                Toast.makeText(PickActivity.this, "Kaydedildi", Toast.LENGTH_SHORT).show();
                finish();
            }
            return true;
        }
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        keyCode = getIntent().getIntExtra("key", 0);
        View v = new V(this);
        v.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        setContentView(v);
    }
}
