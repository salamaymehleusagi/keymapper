package com.example.keymapper;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.LinkedHashMap;
import java.util.Map;

public class Store {
    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("km", Context.MODE_PRIVATE);
    }

    // keycode -> {x, y}
    static Map<Integer, float[]> load(Context c) {
        Map<Integer, float[]> m = new LinkedHashMap<>();
        String s = sp(c).getString("map", "");
        for (String part : s.split(";")) {
            String[] a = part.split(":");
            if (a.length == 3) {
                try {
                    m.put(Integer.parseInt(a[0]),
                        new float[]{Float.parseFloat(a[1]), Float.parseFloat(a[2])});
                } catch (Exception ignored) {}
            }
        }
        return m;
    }

    static void save(Context c, Map<Integer, float[]> m) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Integer, float[]> e : m.entrySet()) {
            sb.append(e.getKey()).append(":").append(e.getValue()[0])
              .append(":").append(e.getValue()[1]).append(";");
        }
        sp(c).edit().putString("map", sb.toString()).apply();
    }

    static void put(Context c, int key, float x, float y) {
        Map<Integer, float[]> m = load(c);
        m.put(key, new float[]{x, y});
        save(c, m);
    }

    static void remove(Context c, int key) {
        Map<Integer, float[]> m = load(c);
        m.remove(key);
        save(c, m);
    }

    static boolean enabled(Context c) { return sp(c).getBoolean("on", true); }
    static void setEnabled(Context c, boolean v) { sp(c).edit().putBoolean("on", v).apply(); }
}
