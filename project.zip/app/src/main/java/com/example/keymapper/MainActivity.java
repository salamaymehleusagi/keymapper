package com.example.keymapper;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.KeyEvent;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {
    boolean waiting = false;
    TextView info;
    ListView list;
    Button addBtn, toggleBtn;
    List<Integer> keys = new ArrayList<>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 64, 32, 32);

        info = new TextView(this);
        info.setTextSize(16);
        root.addView(info);

        Button acc = new Button(this);
        acc.setText("1) Erisilebilirlik ayarini ac (servisi aktif et)");
        acc.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(acc);

        addBtn = new Button(this);
        addBtn.setText("2) Yeni tus ekle");
        addBtn.setOnClickListener(v -> {
            waiting = true;
            info.setText("Simdi eslemek istedigin tusa bas (klavye ya da kumanda)...");
        });
        root.addView(addBtn);

        toggleBtn = new Button(this);
        toggleBtn.setOnClickListener(v -> {
            Store.setEnabled(this, !Store.enabled(this));
            refresh();
        });
        root.addView(toggleBtn);

        list = new ListView(this);
        list.setOnItemClickListener((p, v, pos, id) -> {
            Store.remove(this, keys.get(pos));
            refresh();
        });
        root.addView(list);
        setContentView(root);
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    void refresh() {
        info.setText("Eslemeler (silmek icin uzerine dokun):");
        toggleBtn.setText(Store.enabled(this) ? "Eslemeler ACIK (kapatmak icin dokun)"
                                              : "Eslemeler KAPALI (acmak icin dokun)");
        keys.clear();
        List<String> rows = new ArrayList<>();
        for (Map.Entry<Integer, float[]> e : Store.load(this).entrySet()) {
            keys.add(e.getKey());
            rows.add(KeyEvent.keyCodeToString(e.getKey()) + "  ->  ("
                + (int) e.getValue()[0] + ", " + (int) e.getValue()[1] + ")");
        }
        list.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, rows));
    }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (waiting && e.getAction() == KeyEvent.ACTION_DOWN
                && e.getKeyCode() != KeyEvent.KEYCODE_BACK) {
            waiting = false;
            Intent i = new Intent(this, PickActivity.class);
            i.putExtra("key", e.getKeyCode());
            startActivity(i);
            return true;
        }
        return super.dispatchKeyEvent(e);
    }
}
