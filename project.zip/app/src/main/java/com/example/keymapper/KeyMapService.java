package com.example.keymapper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import java.util.Map;

public class KeyMapService extends AccessibilityService {
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}

    @Override
    protected boolean onKeyEvent(KeyEvent e) {
        if (!Store.enabled(this)) return false;
        Map<Integer, float[]> m = Store.load(this);
        float[] pos = m.get(e.getKeyCode());
        if (pos == null) return false;
        if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) {
            tap(pos[0], pos[1]);
        }
        return true; // tuşu biz yedik, oyuna normal tuş olarak gitmesin
    }

    private void tap(float x, float y) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(p, 0, 50));
        dispatchGesture(b.build(), null, null);
    }
}
