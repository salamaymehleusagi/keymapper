# KeyMapper v2 (Android, Kotlin) — Shizuku'suz, yerleşik kablosuz ADB

## Derleme
`./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`  (JDK 17, internet: JitPack)

## Kurulum
1. Overlay iznini ver.
2. Ayarlar > Geliştirici seçenekleri > **Kablosuz hata ayıklama**'yı aç (Wi-Fi bağlı olmalı).
3. "Eşleme koduyla cihazı eşle" ekranındaki port + 6 haneli kodu uygulamaya gir -> **Eşle**.
   (Ekran kapanırsa **Bildirimden eşle**: bildirime "port kod" yaz.)
4. Kablosuz hata ayıklama ana ekranındaki portu gir -> **Bağlan** (veya **Otomatik bağlan**).
5. **Enjektörü başlat** (shell yetkisiyle app_process sunucusu açılır; sonra ADB'yi kapatabilirsin).
6. **Yüzen ikonu başlat** -> oyunda ikona dokun -> editör -> **▶ Oyna**.

## Mimari
- adb/KeyMapperAdb   : libadb-android ile pair/connect, kalıcı RSA anahtarı
- adb/AdbHelper      : pair, connect, shell, enjektörü başlat
- shell/InjectorMain : shell kullanıcısında çalışan sunucu (127.0.0.1, token korumalı), çoklu dokunuş MotionEvent
- adb/InjectorClient : sunucuya soket istemcisi (TouchBackend)
- core/InputEngine   : tuş/fare/gamepad -> parmaklar (chord, tap/hold, turbo, gecikme, makro)
- core/A11yTouchBackend : yedek yöntem
- service/FloatingService, ui/EditorView, ui/CaptureView, ui/MainActivity
