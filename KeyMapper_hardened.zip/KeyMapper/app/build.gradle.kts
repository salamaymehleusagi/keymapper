plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.keymapper"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.keymapper"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // NOT: Hâlâ debug imzasıyla imzalanıyor. Dağıtmadan önce kendi
            // release keystore'unu oluşturup burada signingConfigs.getByName("release")
            // ile değiştir — debug anahtarıyla imzalanmış bir APK herkes tarafından
            // yeniden imzalanıp değiştirilebilir.
            signingConfig = signingConfigs.getByName("debug")
        }
        debug {
            // release derlemesinde obfuscation'ı test etmek istersen:
            // isMinifyEnabled = true; proguardFiles(...)
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        // SecurityGuard.kt, release/debug ayrımı için BuildConfig.DEBUG kullanıyor
        // (AGP 8+'ta bu varsayılan olarak kapalı, açıkça açmak gerekiyor).
        buildConfig = true
    }
    packaging {
        resources {
            excludes += setOf(
                "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/DEPENDENCIES",
                "META-INF/AL2.0", "META-INF/LGPL2.1"
            )
        }
    }
}

dependencies {
    // Yerleşik ADB istemcisi (pair / connect / shell) – Shizuku YOK
    implementation("com.github.MuntashirAkon:libadb-android:3.1.0")
    implementation("org.conscrypt:conscrypt-android:2.5.3")               // ADB TLS (kablosuz hata ayıklama)
}
