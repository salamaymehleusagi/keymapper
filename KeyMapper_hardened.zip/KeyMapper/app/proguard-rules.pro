# ProGuard / R8 kuralları (release derlemesi minifyEnabled=true)
#
# Amaç: kod küçültme + isim belirsizleştirme (obfuscation) ile statik
# decompile sonucunu okunaksız hale getirmek. "Kırılmaz" yapmaz, ama
# jadx/apktool ile bakan birinin işini ciddi şekilde zorlaştırır.

# ---------------------------------------------------------------------------
# KRİTİK: InjectorMain `adb shell app_process ... com.example.keymapper.shell.
# InjectorMain <port> <token>` komutuyla, tam nitelikli sınıf adı STRING olarak
# çağrılıyor (bkz. AdbHelper.kt). Kotlin tarafında buna statik bir referans
# YOK, bu yüzden R8 bunu "kullanılmıyor" sanıp silebilir veya adını
# değiştirebilir — ikisi de enjektörü çalışma anında sessizce bozar.
# Sınıf adı ve main() imzası AYNEN kalmalı.
# ---------------------------------------------------------------------------
-keep class com.example.keymapper.shell.InjectorMain {
    public static void main(java.lang.String[]);
}

# Android bileşenleri (manifest'te adla referans edilir) zaten AGP'nin
# varsayılan kurallarıyla korunur, ama açıkça da belirtelim:
-keep class com.example.keymapper.KeyMapperApp
-keep class com.example.keymapper.ui.MainActivity
-keep class com.example.keymapper.service.FloatingService
-keep class com.example.keymapper.service.KeyMapperAccessibilityService
-keep class com.example.keymapper.adb.PairingReceiver

# libadb-android / conscrypt kendi consumer-rules.pro dosyalarını APK'ya
# gömer (AAR içinden), o yüzden burada tekrar yazmaya gerek yok. Sorun
# çıkarsa (ör. "ClassNotFoundException" / "NoSuchMethodException" runtime'da)
# şu satırı aç ve hangi paketin kırıldığını logcat'ten bul:
# -keep class com.mauntashir.** { *; }  # örnek — gerçek paket adını kullan

# ---------------------------------------------------------------------------
# Release derlemesinde Log.* çağrılarını komple sil (performans + tersine
# mühendislik sırasında "hangi adım nerede" bilgisini azaltır). debug build
# bundan etkilenmez.
# ---------------------------------------------------------------------------
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
    public static int wtf(...);
}

# Kotlin coroutines / metadata uyarılarını bastır (gerekirse)
-dontwarn kotlinx.coroutines.**
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod

# Satır numaralarını çökme raporları için SourceFile'a eşleyip gerçek
# dosya adını gizle (obfuscation'ı biraz daha güçlendirir)
-keepattributes SourceFile
-renamesourcefileattribute SourceFile
