package com.example.keymapper.ui

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.example.keymapper.adb.AdbHelper
import com.example.keymapper.adb.InjectorClient
import com.example.keymapper.adb.PairingNotifier
import com.example.keymapper.data.Prefs
import com.example.keymapper.data.ProfileRepository
import com.example.keymapper.model.Profile
import com.example.keymapper.service.FloatingService
import com.example.keymapper.service.KeyMapperAccessibilityService

/**
 * Ana ekran. Sıra: Gerekli izinler (en üstte) -> Oyunlar -> Oyun paneli -> ADB kurulumu -> Fare -> Profiller.
 * Arayüz kodla kurulur (koyu tema, kartlar).
 */
class MainActivity : Activity() {

    private lateinit var repo: ProfileRepository
    private lateinit var scroll: ScrollView
    private lateinit var headStatus: TextView
    private lateinit var permBox: LinearLayout
    private lateinit var gamesBox: LinearLayout
    private lateinit var profilesBox: LinearLayout
    private lateinit var adbCard: LinearLayout
    private lateinit var adbBody: LinearLayout
    private lateinit var tvLog: TextView
    private lateinit var etHost: EditText
    private lateinit var etPairPort: EditText
    private lateinit var etPairCode: EditText
    private lateinit var etConnPort: EditText
    private var pendingExport: Profile? = null

    // ---- renkler ----
    private val BG = 0xFF0F1115.toInt()
    private val CARD = 0xFF181B22.toInt()
    private val TEXT = 0xFFECEFF4.toInt()
    private val SUB = 0xFF9AA4B2.toInt()
    private val ACCENT = 0xFF3DDC84.toInt()
    private val BTN = 0xFF262B35.toInt()

    // ------------------------------------------------------------------ yardımcılar
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun log(s: String) { tvLog.text = s }

    private fun text(t: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun button(t: String, accent: Boolean = false, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; minHeight = dp(44)
        setTextColor(if (accent) 0xFF00170A.toInt() else TEXT)
        background = GradientDrawable().apply {
            setColor(if (accent) ACCENT else BTN); cornerRadius = dp(10).toFloat()
        }
        setOnClickListener { onClick() }
    }

    private fun field(hint: String, number: Boolean = false, maxLen: Int = 0) = EditText(this).apply {
        this.hint = hint; setHintTextColor(SUB); setTextColor(TEXT); textSize = 14f
        inputType = if (number) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
        if (maxLen > 0) filters = arrayOf(InputFilter.LengthFilter(maxLen))
    }

    private fun check(t: String, on: Boolean, onChange: (Boolean) -> Unit) = CheckBox(this).apply {
        text = t; setTextColor(TEXT); isChecked = on
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(CARD); cornerRadius = dp(16).toFloat() }
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        parent.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        c.addView(text(title, 16f, TEXT, true))
        return c
    }

    private fun add(parent: LinearLayout, v: View, top: Int = 6) =
        parent.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })

    /** Bloklayıcı işi ADB kuyruğunda çalıştırır; sonucu/hatayı ekrana yazar. */
    private fun bg(startMsg: String, work: () -> String) {
        log(startMsg)
        AdbHelper.io.execute {
            val res = try { work() } catch (e: Throwable) { "Hata: ${e.message ?: e.javaClass.simpleName}" }
            runOnUiThread { log(res); refreshAll() }
        }
    }

    private fun host(): String = etHost.text.toString().trim().ifEmpty { "127.0.0.1" }
        .also { Prefs.setLastHost(this, it) }
    private fun num(e: EditText): Int = e.text.toString().trim().toIntOrNull() ?: -1

    // ------------------------------------------------------------------ arayüz
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        repo = ProfileRepository(this)
        window.statusBarColor = BG

        scroll = ScrollView(this).apply { setBackgroundColor(BG); isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(40))
        }
        scroll.addView(root)
        setContentView(scroll)

        // ---- başlık ----
        root.addView(text("KeyMapper Pro", 28f, TEXT, true))
        root.addView(text("Klavye · Fare · Gamepad → dokunmatik oyunlar", 13f, SUB))
        headStatus = text("", 14f, ACCENT, true)
        add(root, headStatus, 8)

        // ---- 1) GEREKLİ İZİNLER (en üstte) ----
        val permCard = card(root, "Gerekli izinler")
        permBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        permCard.addView(permBox)

        // ---- 2) OYUNLAR ----
        val gamesCard = card(root, "Oyunlarım")
        gamesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        gamesCard.addView(gamesBox)
        add(gamesCard, button("＋ Oyun ekle", true) { addGameDialog() }, 10)
        gamesCard.addView(text("Oyun, kendi profiliyle ve yüzen panelle başlar. (Şu an normal ortamda açılır; " +
            "sanal ortam/klon desteği yok.)", 11f, SUB))

        // ---- 3) OYUN PANELİ ----
        val panelCard = card(root, "Oyun paneli")
        val prow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        prow.addView(button("▶ Paneli başlat", true) {
            if (!Settings.canDrawOverlays(this)) { toast("Önce overlay iznini ver"); return@button }
            startForegroundService(Intent(this, FloatingService::class.java))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        prow.addView(button("■ Durdur") { stopService(Intent(this, FloatingService::class.java)) },
            LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) })
        add(panelCard, prow, 8)

        // ---- 4) KABLOSUZ ADB ----
        adbCard = card(root, "Kablosuz ADB (dokunuş enjeksiyonu)")
        add(adbCard, button("Göster / Gizle") {
            adbBody.visibility = if (adbBody.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        })
        adbBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (AdbHelper.connected) View.GONE else View.VISIBLE
        }
        adbCard.addView(adbBody)
        buildAdbBody()

        // ---- 5) FARE ----
        val mouseCard = card(root, "Fare")
        add(mouseCard, check("Fareyi yakala: fare hareketi basılı tuşları kesmez (önerilir)",
            Prefs.captureMouse(this)) { Prefs.setCaptureMouse(this, it) })
        add(mouseCard, check("Sanal fare imleci göster (sol tık = imlecin altına dokun)",
            Prefs.virtualCursor(this)) { Prefs.setVirtualCursor(this, it) })
        val speedLabel = text("İmleç hızı: ${"%.1f".format(Prefs.cursorSpeed(this))}", 13f, SUB)
        add(mouseCard, speedLabel, 8)
        val speed = SeekBar(this).apply {
            max = 100
            progress = (((Prefs.cursorSpeed(this@MainActivity) - 0.3f) / 2.7f) * 100).toInt().coerceIn(0, 100)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    val v = 0.3f + 2.7f * p / 100f
                    Prefs.setCursorSpeed(this@MainActivity, v)
                    speedLabel.text = "İmleç hızı: ${"%.1f".format(v)}"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        add(mouseCard, speed, 2)

        // ---- 6) PROFİLLER ----
        val profCard = card(root, "Profiller (dokun: aktif yap, uzun bas: menü)")
        profilesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        profCard.addView(profilesBox)
        val pr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        pr.addView(button("Yeni profil") { newProfileDialog() }, LinearLayout.LayoutParams(0, -2, 1f))
        pr.addView(button("JSON içe aktar") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, REQ_IMPORT)
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) })
        add(profCard, pr, 8)
    }

    private fun buildAdbBody() {
        adbBody.addView(text("Ayarlar > Geliştirici seçenekleri > Kablosuz hata ayıklama'yı aç (Wi-Fi bağlı olmalı). " +
            "Eşleme için 'Eşleme koduyla cihazı eşle' ekranındaki port ve 6 haneli kodu gir. " +
            "Ekran kapanırsa 'Bildirimden eşle'yi kullan.", 12f, SUB))
        etHost = field("IP (aynı cihaz için 127.0.0.1)").apply { setText(Prefs.lastHost(this@MainActivity)) }
        etPairPort = field("Eşleme portu", true)
        etPairCode = field("6 haneli kod", true, 6)
        etConnPort = field("Bağlantı portu (Kablosuz hata ayıklama ana ekranındaki)", true)
        add(adbBody, etHost)
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r1.addView(etPairPort, LinearLayout.LayoutParams(0, -2, 1f))
        r1.addView(etPairCode, LinearLayout.LayoutParams(0, -2, 1f))
        add(adbBody, r1)
        add(adbBody, button("Eşle (adb pair)") {
            val h = host(); val port = num(etPairPort); val code = etPairCode.text.toString().trim()
            if (port <= 0 || code.length != 6) { log("Eşleme portu ve 6 haneli kodu gir"); return@button }
            bg("Eşleniyor…") { AdbHelper.pair(this, h, port, code); "Eşleme başarılı ✅ Şimdi 'Bağlan'a bas." }
        })
        add(adbBody, button("Bildirimden eşle (kodu bildirime yaz)") {
            Prefs.setLastHost(this, host())
            PairingNotifier.showInput(this)
            log("Bildirim gönderildi. Ayarlar'da 'Eşleme koduyla eşle'yi aç, bildirime 'port kod' yaz.")
        })
        add(adbBody, etConnPort, 10)
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r2.addView(button("Bağlan") {
            val h = host(); val port = num(etConnPort)
            if (port <= 0) { log("Bağlantı portunu gir"); return@button }
            bg("Bağlanılıyor…") { AdbHelper.connect(this, h, port); "ADB bağlandı ✅ Şimdi 'Enjektörü başlat'." }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        r2.addView(button("Otomatik bağlan") {
            bg("Otomatik aranıyor (mDNS)…") { AdbHelper.autoConnect(this); "ADB bağlandı ✅ Şimdi 'Enjektörü başlat'." }
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) })
        add(adbBody, r2)
        add(adbBody, button("Enjektörü başlat", true) { startInjectorAction() }, 10)
        add(adbBody, button("Enjektörü test et (bağlantı + ping)") {
            bg("Test ediliyor…") {
                when {
                    !InjectorClient.connectBlocking(this) ->
                        "Enjektöre bağlanılamadı ❌ ${InjectorClient.lastError}\n'Enjektörü başlat'a bas (önce ADB bağlı olmalı)."
                    !InjectorClient.injectOk -> "Sunucu açık ama dokunuş enjeksiyonu API'si yok ❌"
                    InjectorClient.ping() -> "Enjektör yanıt veriyor ✅ dokunuş enjeksiyonu hazır."
                    else -> "Enjektör yanıt vermedi ❌ ${InjectorClient.lastError}"
                }
            }
        })
        tvLog = text("", 12f, SUB).apply { typeface = Typeface.MONOSPACE; setTextIsSelectable(true) }
        add(adbBody, tvLog, 8)
        add(adbBody, button("Günlüğü kopyala") {
            val cm = getSystemService(ClipboardManager::class.java)
            cm.setPrimaryClip(ClipData.newPlainText("KeyMapper günlük", tvLog.text))
            toast("Günlük kopyalandı")
        })
    }

    private fun startInjectorAction() {
        adbBody.visibility = View.VISIBLE
        bg("Enjektör başlatılıyor…") {
            val (ok, msg) = AdbHelper.startInjector(this)
            if (ok) "$msg\nArtık oyun panelini başlatabilirsin. Oynarken kablosuz hata ayıklamayı KAPATMA." else msg
        }
    }

    override fun onResume() {
        super.onResume()
        refreshAll()
    }

    private fun refreshAll() {
        refreshPerms(); refreshGames(); refreshProfiles()
    }

    // ------------------------------------------------------------------ izinler (en üstte)
    private fun permRow(title: String, desc: String, ok: Boolean, action: String, onAction: () -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tx.addView(text((if (ok) "✅  " else "❌  ") + title, 15f, TEXT, true))
        tx.addView(text(desc, 12f, SUB))
        row.addView(tx, LinearLayout.LayoutParams(0, -2, 1f))
        if (!ok) row.addView(button(action, true, onAction), LinearLayout.LayoutParams(-2, -2))
        permBox.addView(row, LinearLayout.LayoutParams(-1, -2))
    }

    private fun refreshPerms() {
        permBox.removeAllViews()
        val overlay = Settings.canDrawOverlays(this)
        val notif = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val adb = AdbHelper.connected
        val inj = InjectorClient.isActive
        val a11y = KeyMapperAccessibilityService.instance != null

        permRow("Diğer uygulamaların üzerinde göster", "Yüzen panel, sanal imleç ve tuş yakalama için zorunlu",
            overlay, "İzin ver") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        permRow("Bildirimler", "Servisin arka planda çalışması için", notif, "İzin ver") {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        permRow("Kablosuz hata ayıklama (ADB)", "Dokunuş enjeksiyonu için: eşle ve bağlan", adb, "Kur") {
            adbBody.visibility = View.VISIBLE
            scroll.post { scroll.smoothScrollTo(0, adbCard.top) }
        }
        permRow("Enjektör", "Shell yetkili dokunuş sunucusu", inj, "Başlat") { startInjectorAction() }
        permRow("Erişilebilirlik (yedek, isteğe bağlı)", "ADB olmadan yedek yöntem; açık oyunu da algılar",
            a11y, "Aç") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        val ready = overlay && (inj || a11y)
        headStatus.text = if (ready) "● Hazır — oyun ekleyip başlatabilirsin" else "● Kurulum gerekli — aşağıdaki izinleri tamamla"
        headStatus.setTextColor(if (ready) ACCENT else 0xFFFFB74D.toInt())
    }

    // ------------------------------------------------------------------ oyunlar
    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    private fun refreshGames() {
        gamesBox.removeAllViews()
        val games = Prefs.games(this)
        if (games.isEmpty()) {
            gamesBox.addView(text("Henüz oyun yok. \"Oyun ekle\" ile yüklü bir oyunu seç.", 13f, SUB))
            return
        }
        for (pkg in games) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            val icon = ImageView(this)
            try { icon.setImageDrawable(packageManager.getApplicationIcon(pkg)) } catch (_: Exception) {}
            row.addView(icon, LinearLayout.LayoutParams(dp(44), dp(44)))
            val name = text(appLabel(pkg), 15f, TEXT, true)
            row.addView(name, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
            row.addView(button("Başlat", true) { launchGame(pkg) }, LinearLayout.LayoutParams(-2, -2))
            row.addView(button("✕") {
                AlertDialog.Builder(this).setTitle(appLabel(pkg))
                    .setMessage("Listeden kaldırılsın mı? (Profil silinmez)")
                    .setPositiveButton("Kaldır") { _, _ -> Prefs.removeGame(this, pkg); refreshGames() }
                    .setNegativeButton("İptal", null).show()
            }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(6) })
            gamesBox.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
    }

    /** Oyunu kendi profiliyle ve yüzen panelle başlatır. */
    private fun launchGame(pkg: String) {
        if (!Settings.canDrawOverlays(this)) { toast("Önce overlay iznini ver"); return }
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) { toast("Oyun açılamadı"); return }
        val name = appLabel(pkg)
        if (repo.load(name) == null) repo.save(Profile(name))      // oyuna özel profil
        Prefs.setPkgProfile(this, pkg, name)
        Prefs.setActiveProfile(this, name)
        startForegroundService(
            Intent(this, FloatingService::class.java).putExtra("profile", name).putExtra("pkg", pkg)
        )
        startActivity(intent)
    }

    private fun addGameDialog() {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val have = Prefs.games(this)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName && !have.contains(it.first) }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        if (apps.isEmpty()) { toast("Eklenecek uygulama bulunamadı"); return }

        val adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(i: Int) = apps[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, convert: View?, parent: ViewGroup?): View {
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(16), dp(8), dp(16), dp(8))
                }
                val ic = ImageView(this@MainActivity)
                try { ic.setImageDrawable(pm.getApplicationIcon(apps[i].first)) } catch (_: Exception) {}
                row.addView(ic, LinearLayout.LayoutParams(dp(40), dp(40)))
                row.addView(TextView(this@MainActivity).apply { text = apps[i].second; textSize = 16f },
                    LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
                return row
            }
        }
        AlertDialog.Builder(this).setTitle("Oyun ekle")
            .setAdapter(adapter) { _, i -> Prefs.addGame(this, apps[i].first); refreshGames() }
            .setNegativeButton("İptal", null).show()
    }

    // ------------------------------------------------------------------ profil yönetimi
    private fun refreshProfiles() {
        profilesBox.removeAllViews()
        val active = Prefs.activeProfile(this)
        for (name in repo.list()) {
            profilesBox.addView(text((if (name == active) "●  " else "○  ") + name, 16f, TEXT).apply {
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { Prefs.setActiveProfile(this@MainActivity, name); refreshProfiles() }
                setOnLongClickListener { profileMenu(name); true }
            })
        }
    }

    private fun profileMenu(name: String) {
        AlertDialog.Builder(this).setTitle(name)
            .setItems(arrayOf("JSON olarak dışa aktar", "Sil")) { _, i ->
                if (i == 0) {
                    pendingExport = repo.load(name)
                    startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
                        putExtra(Intent.EXTRA_TITLE, "$name.json")
                    }, REQ_EXPORT)
                } else { repo.delete(name); refreshProfiles() }
            }.show()
    }

    private fun newProfileDialog() {
        val et = EditText(this).apply { hint = "Profil adı (ör. PUBG)" }
        AlertDialog.Builder(this).setTitle("Yeni profil").setView(et)
            .setPositiveButton("Oluştur") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) {
                    repo.save(Profile(n)); Prefs.setActiveProfile(this, n); refreshProfiles()
                }
            }.setNegativeButton("İptal", null).show()
    }

    @Deprecated("Basit tutmak için klasik API")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        try {
            when (req) {
                REQ_IMPORT -> {
                    val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                    val p = repo.importJson(text)
                    toast("İçe aktarıldı: ${p.name}"); refreshProfiles()
                }
                REQ_EXPORT -> pendingExport?.let { p ->
                    contentResolver.openOutputStream(uri)!!.bufferedWriter().use { it.write(repo.exportJson(p)) }
                    toast("Dışa aktarıldı")
                }
            }
        } catch (e: Exception) { toast("Hata: ${e.message}") }
    }

    companion object { private const val REQ_IMPORT = 10; private const val REQ_EXPORT = 11 }
}
