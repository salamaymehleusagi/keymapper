package com.example.keymapper

import android.app.Application
import com.example.keymapper.security.SecurityGuard
import org.conscrypt.Conscrypt
import java.security.Security
import kotlin.system.exitProcess

class KeyMapperApp : Application() {
    override fun onCreate() {
        super.onCreate()

        // Anti-tamper: release build'de, imza eşleşmiyorsa veya bir debugger
        // bağlıysa, geri kalan hiçbir kodu (ADB/enjektör dahil) çalıştırmadan
        // hemen çık. SecurityGuard.EXPECTED_SIGNATURE_SHA256'yı kendi release
        // sertifikanla doldurmadan bu kontrol pasif kalır.
        if (SecurityGuard.shouldAbort(this)) {
            exitProcess(0)
        }

        // Kablosuz hata ayıklama (TLS 1.3) için Conscrypt'i birinci sağlayıcı yap
        Security.insertProviderAt(Conscrypt.newProvider(), 1)
    }
}
