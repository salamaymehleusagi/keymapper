package com.example.keymapper.core

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import com.example.keymapper.model.Binding
import com.example.keymapper.model.ElementType
import com.example.keymapper.model.MappingElement
import com.example.keymapper.model.Profile
import com.example.keymapper.model.StickSource
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Girdi motoru: klavye / fare / gamepad olaylarını profildeki elemanlara göre sanal
 * dokunuşlara (TouchBackend) çevirir. Tüm çağrılar ana thread'dedir.
 *
 * Çoklu dokunuş: her eleman kendi parmak (pointer) id'sini alır; A+W gibi aynı anda basılan
 * tuşlar ayrı parmaklar olarak eşzamanlı enjekte edilir. WASD tek sanal joystick olduğundan
 * çapraz hareket tek parmağın vektörüyle verilir (çakışma olmaz).
 *
 * Tuş kombinasyonu (chord): binding "K:59+K:29" (Shift+A) -> tüm parçalar basılıyken aktif olur.
 */
class InputEngine(private val backendProvider: () -> TouchBackend?) {

    var profile = Profile("Default")
    var screenW = 1080
    var screenH = 1920
    /** Oyun modu başlarken fare yakalansın mı (kamera elemanı olmasa bile). */
    var captureMouseOnStart = true
    /** Aimlock/Shiftlock değişince çağrılır (fare yakalamayı aç/kapat). */
    var onLockChanged: ((Boolean) -> Unit)? = null

    // ---- Sanal fare imleci (gerçek fare yakalanır; imleci biz çizeriz) ----
    var cursorEnabled = true
    var cursorSpeed = 1.2f
    var cursorX = 0f; private set
    var cursorY = 0f; private set
    /** (x, y, görünür mü) — imleç penceresini günceller. */
    var onCursor: ((Float, Float, Boolean) -> Unit)? = null
    private var clickThrough = false
    private var cursorPtr: Int? = null

    var running = false; private set
    var locked = false; private set

    private val h = Handler(Looper.getMainLooper())

    // --- AYRI parmak id havuzları ---
    // Klavye / gamepad / tuş dokunuşları: id 0..6   |   Fare-kamera (mouse look): id 7..9
    // Kamera parmağı hiçbir zaman tuş parmaklarının id'sini alamaz ve onları etkileyemez.
    private val freeKey = ArrayDeque<Int>()
    private val freeCam = ArrayDeque<Int>()
    private val allocated = HashSet<Int>()
    private fun resetPool() {
        freeKey.clear(); freeKey.addAll((0 until CAM_BASE).toList())
        freeCam.clear(); freeCam.addAll((CAM_BASE..9).toList())
        allocated.clear()
    }
    private fun alloc(): Int? = freeKey.removeFirstOrNull()?.also { allocated.add(it) }
    private fun allocCam(): Int? = freeCam.removeFirstOrNull()?.also { allocated.add(it) }
    private fun release(id: Int) {
        if (allocated.remove(id)) { if (id >= CAM_BASE) freeCam.addLast(id) else freeKey.addLast(id) }
    }

    private val pointerOf = HashMap<String, Int>()      // eleman id -> parmak id (buton/joystick)
    private class Cam(var id: Int, var x: Float, var y: Float)
    private val cam = HashMap<String, Cam>()
    private val camIdle = HashMap<String, Runnable>()
    private class JoyState(var id: Int, var x: Float, var y: Float, var tx: Float, var ty: Float)
    private val joy = HashMap<String, JoyState>()

    private val tokens = HashMap<String, Any>()          // makro / turbo zincirlerini iptal etmek için
    private val pending = HashMap<String, Runnable>()    // gecikmeli başlatmalar
    private val active = HashSet<String>()               // şu an aktif (tuşları basılı) elemanlar

    private val keysDown = HashSet<Int>()
    private val held = HashSet<String>()                 // basılı binding parçaları
    private val synth = HashSet<Int>()                   // eksenlerden türetilen sanal tuşlar
    private var lx = 0f; private var ly = 0f; private var rx = 0f; private var ry = 0f
    private var lastButtons = 0

    init { resetPool() }

    private fun minDim() = min(screenW, screenH).toFloat()
    private fun parts(el: MappingElement) = el.binding.split("+").filter { it.isNotEmpty() }

    // ------------------------------------------------------------------ yaşam döngüsü
    fun start() {
        resetPool()
        running = true
        val hasCam = profile.elements.any { it.type == ElementType.CAMERA }
        val hasToggle = profile.elements.any { it.type == ElementType.LOCK_TOGGLE }
        // Fare yakalama: imleç gizlenir, fare olayları oyuna/sisteme gitmez; sadece motorumuza gelir.
        // Yakalanmazsa her fare hareketi gerçek fare olayı üretir ve enjekte dokunuşları keser.
        // 'locked' = KAMERA modu (mouse look). Değilse sanal imleç modu. Yakalama ikisinde de açık.
        locked = hasCam && !hasToggle
        cursorX = screenW / 2f; cursorY = screenH / 2f
        onLockChanged?.invoke(locked)
        notifyCursor()
        h.post(ticker)
    }

    fun stop() {
        running = false
        clearState()
        notifyCursor()
    }

    /** Fare (Pointer Capture) yakalansın mı? Kamera modunda veya ayar açıksa. */
    fun wantsCapture() = captureMouseOnStart || locked

    /**
     * Tüm girdileri anında bırakır (odak kaybı, profil değişimi, durdurma). Takılı kalan
     * tuş/dokunuş kalmamasını garanti eder.
     */
    fun releaseInputs() {
        clearState()
        if (running) h.post(ticker)
    }

    private val focusRelease = Runnable { releaseInputs() }

    /** Capture penceresi odağı kaybetti: hemen sıfırlama; [FOCUS_GRACE] içinde geri gelmezse bırak. */
    fun onFocusLost() {
        if (!running) return
        h.removeCallbacks(focusRelease)
        h.postDelayed(focusRelease, FOCUS_GRACE)
    }

    /** Odak geri geldi: bekleyen sıfırlamayı iptal et, basılı tuşlar korunur. */
    fun onFocusGained() { h.removeCallbacks(focusRelease) }

    private fun clearState() {
        h.removeCallbacksAndMessages(null)
        releaseAll()
        keysDown.clear(); held.clear(); synth.clear(); active.clear()
        tokens.clear(); pending.clear()
        lx = 0f; ly = 0f; rx = 0f; ry = 0f; lastButtons = 0
    }

    private fun releaseAll() {
        val be = backendProvider()
        allocated.toList().forEach { be?.up(it) }
        be?.reset()
        pointerOf.clear(); cam.clear(); camIdle.clear(); joy.clear()
        cursorPtr = null; clickThrough = false
        resetPool()
    }

    // ------------------------------------------------------------------ klavye / gamepad tuşları
    fun onKey(e: KeyEvent): Boolean {
        if (!running) return false
        val down = e.action == KeyEvent.ACTION_DOWN
        val code = Binding.codeOf(e)                                     // WASD: fiziksel konum
        if (down && e.repeatCount > 0) return isBoundKey(code)           // tekrar eden olayları yut
        if (e.action != KeyEvent.ACTION_DOWN && e.action != KeyEvent.ACTION_UP) return false
        return keyCode(code, down)
    }

    private fun keyCode(code: Int, down: Boolean): Boolean {
        if (down) keysDown.add(code) else keysDown.remove(code)
        val a = onBinding("K:$code", down)
        val b = refreshKeyJoysticks(code)
        return a || b
    }

    private fun joyKeys(s: StickSource): IntArray? = when (s) {
        StickSource.WASD -> intArrayOf(KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D)
        StickSource.ARROWS -> intArrayOf(KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_LEFT,
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_RIGHT)
        else -> null
    }

    private fun isBoundKey(code: Int) = profile.elements.any {
        parts(it).contains("K:$code") ||
            (it.type == ElementType.JOYSTICK && joyKeys(it.stick)?.contains(code) == true)
    }

    private fun refreshKeyJoysticks(code: Int): Boolean {
        var used = false
        for (el in profile.elements) {
            if (el.type != ElementType.JOYSTICK) continue
            val k = joyKeys(el.stick) ?: continue
            if (!k.contains(code)) continue
            used = true
            // k = [yukarı, sol, aşağı, sağ]
            val vx = (if (keysDown.contains(k[3])) 1f else 0f) - (if (keysDown.contains(k[1])) 1f else 0f)
            val vy = (if (keysDown.contains(k[2])) 1f else 0f) - (if (keysDown.contains(k[0])) 1f else 0f)
            updateJoystick(el, vx, vy)
        }
        return used
    }

    // ------------------------------------------------------------------ tuş -> eleman (chord destekli)
    private fun onBinding(b: String, down: Boolean): Boolean {
        if (down) held.add(b) else held.remove(b)
        var consumed = false
        for (el in profile.elements) {
            if (el.binding.isEmpty()) continue
            val p = parts(el)
            if (!p.contains(b)) continue
            consumed = true
            val now = p.all { held.contains(it) }
            val was = active.contains(el.id)
            if (now && !was) { active.add(el.id); trigger(el, true) }
            else if (!now && was) { active.remove(el.id); trigger(el, false) }
        }
        return consumed
    }

    private fun trigger(el: MappingElement, down: Boolean) {
        when (el.type) {
            ElementType.BUTTON -> if (down) startButton(el) else stopButton(el)
            ElementType.MACRO -> if (down) startMacro(el)
            ElementType.SWIPE -> if (down) later(el.delayMs) {
                animateSwipe(el.x * screenW, el.y * screenH, el.x2 * screenW, el.y2 * screenH, el.durationMs)
            }
            ElementType.LOCK_TOGGLE -> if (down) toggleLock()
            else -> {}   // CAMERA: ADS durumu 'active' kümesinden okunur
        }
    }

    private fun later(ms: Long, r: () -> Unit) {
        if (ms > 0) h.postDelayed({ r() }, ms) else r()
    }

    // ------------------------------------------------------------------ BUTTON: Bas-Çek / Basılı Tut / Turbo
    private fun startButton(el: MappingElement) {
        val begin = Runnable {
            pending.remove(el.id)
            when {
                el.hold -> if (active.contains(el.id)) buttonDown(el)    // tuş zaten bırakıldıysa dokunma
                el.turbo -> { val t = Any(); tokens[el.id] = t; turboTick(el, t) }
                else -> if (el.aim) tapAim(el) else tap(el.x * screenW, el.y * screenH, el.tapMs)
            }
        }
        if (el.delayMs > 0) { pending[el.id] = begin; h.postDelayed(begin, el.delayMs) } else begin.run()
    }

    private fun stopButton(el: MappingElement) {
        if (el.hold) {
            pending.remove(el.id)?.let { h.removeCallbacks(it) }
            buttonUp(el)                                    // tuş çekildiği AN dokunma kesilir
        }
        tokens.remove(el.id)                                // turbo zincirini durdur
    }

    private fun turboTick(el: MappingElement, tok: Any) {
        if (tokens[el.id] !== tok || !active.contains(el.id)) return
        if (el.aim) tapAim(el) else tap(el.x * screenW, el.y * screenH, el.tapMs)
        h.postDelayed({ turboTick(el, tok) }, el.intervalMs.coerceAtLeast(el.tapMs + 10))
    }

    private fun buttonDown(el: MappingElement) {
        if (pointerOf.containsKey(el.id)) return
        val be = backendProvider() ?: return
        val id = alloc() ?: return
        be.down(id, el.x * screenW, el.y * screenH)
        pointerOf[el.id] = id
        if (el.aim) {
            val (ax, ay) = aimPoint(el)
            h.postDelayed({ if (pointerOf[el.id] == id) be.move(id, ax, ay) }, 20)
        }
    }

    private fun buttonUp(el: MappingElement) {
        pointerOf.remove(el.id)?.let { backendProvider()?.up(it); release(it) }
    }

    // ------------------------------------------------------------------ sanal joystick
    private fun updateJoystick(el: MappingElement, vx: Float, vy: Float) {
        val be = backendProvider() ?: return
        val mag = hypot(vx, vy)
        val st = joy[el.id]
        if (mag == 0f) {                                  // bırakınca ANINDA kes
            if (st != null) { be.up(st.id); release(st.id); joy.remove(el.id) }
            return
        }
        val k = if (mag > 1f) 1f / mag else 1f           // çapraz hız normalizasyonu
        val r = el.size * minDim() * el.sensitivity
        val cx = el.x * screenW; val cy = el.y * screenH
        val tx = cx + vx * k * r; val ty = cy + vy * k * r
        if (st == null) {
            val id = alloc() ?: return
            be.down(id, cx, cy)
            val ns = JoyState(id, cx, cy, tx, ty)
            joy[el.id] = ns
            if (!el.smooth) { ns.x = tx; ns.y = ty; be.move(id, tx, ty) }   // yumuşak: ticker kaydırır
        } else {
            st.tx = tx; st.ty = ty
            if (!el.smooth) { st.x = tx; st.y = ty; be.move(st.id, tx, ty) }
        }
    }

    /**
     * Yumuşak joystick: parmak merkezden hedefe birkaç karede KAYDIRILIR. Bazı oyunlar
     * DOWN ile aynı anda gelen konumu "sürükleme" saymaz (sağa/sola gitmeme sorunu); bu adım onu çözer.
     */
    private fun stepJoysticks() {
        if (joy.isEmpty()) return
        val be = backendProvider() ?: return
        for (el in profile.elements) {
            if (el.type != ElementType.JOYSTICK) continue
            val st = joy[el.id] ?: continue
            if (st.x == st.tx && st.y == st.ty) continue
            val r = el.size * minDim() * el.sensitivity
            val step = max(r * 0.3f, 6f)
            val dx = st.tx - st.x; val dy = st.ty - st.y
            val d = hypot(dx, dy)
            if (d <= step) { st.x = st.tx; st.y = st.ty } else { st.x += dx / d * step; st.y += dy / d * step }
            be.move(st.id, st.x, st.y)
        }
    }

    // ------------------------------------------------------------------ sanal imleç, tıkla = dokun, fareyle nişan
    private fun notifyCursor() {
        onCursor?.invoke(cursorX, cursorY, running && cursorEnabled && !locked)
    }

    private fun moveCursor(dx: Float, dy: Float) {
        cursorX = (cursorX + dx * cursorSpeed).coerceIn(0f, (screenW - 1).toFloat())
        cursorY = (cursorY + dy * cursorSpeed).coerceIn(0f, (screenH - 1).toFloat())
        notifyCursor()
        val be = backendProvider() ?: return
        cursorPtr?.let { be.move(it, cursorX, cursorY) }           // basılı tutarak sürükleme
        for (el in profile.elements) {
            if (el.type == ElementType.BUTTON && el.aim) {
                val id = pointerOf[el.id] ?: continue
                val (ax, ay) = aimPoint(el)
                be.move(id, ax, ay)
            }
        }
    }

    private fun cursorTouch(down: Boolean) {
        val be = backendProvider() ?: return
        if (down) {
            if (cursorPtr != null) return
            val id = alloc() ?: return
            be.down(id, cursorX, cursorY); cursorPtr = id
        } else {
            cursorPtr?.let { be.up(it); release(it) }
            cursorPtr = null
        }
    }

    /** Nişan noktası: ekran merkezinden imlece olan yön, elemanın yarıçapına ölçeklenir. */
    private fun aimPoint(el: MappingElement): Pair<Float, Float> {
        val cx = el.x * screenW; val cy = el.y * screenH
        val dx = cursorX - screenW / 2f; val dy = cursorY - screenH / 2f
        val d = hypot(dx, dy)
        if (d < 1f) return Pair(cx, cy)
        val maxDist = 0.35f * minDim()
        val r = el.size * minDim() * el.sensitivity
        val f = min(d, maxDist) / maxDist
        return Pair(cx + dx / d * r * f, cy + dy / d * r * f)
    }

    private fun tapAim(el: MappingElement) {
        val be = backendProvider() ?: return
        val id = alloc() ?: return
        be.down(id, el.x * screenW, el.y * screenH)
        val (ax, ay) = aimPoint(el)
        h.postDelayed({ be.move(id, ax, ay) }, 25)
        h.postDelayed({ be.up(id); release(id) }, 25 + el.tapMs.coerceAtLeast(30))
    }

    // ------------------------------------------------------------------ kamera (Mouse Look / sağ analog)
    private fun adsFactor(el: MappingElement) = if (active.contains(el.id)) el.adsSens else 1f

    /**
     * Kamera bölgesinde bir parmak sürükler. Bölge dışına çıkınca bırakılıp merkezden yeniden
     * basılır; böylece sınırsız 360° dönüş sağlanır.
     */
    private fun cameraMove(el: MappingElement, dx: Float, dy: Float) {
        val be = backendProvider() ?: return
        val cx = el.x * screenW; val cy = el.y * screenH; val r = el.size * minDim()
        var st = cam[el.id]
        if (st == null) {
            val id = allocCam() ?: return
            be.down(id, cx, cy); st = Cam(id, cx, cy); cam[el.id] = st
        }
        st.x += dx; st.y += dy
        if (hypot(st.x - cx, st.y - cy) > r) {
            be.up(st.id); release(st.id); cam.remove(el.id)
            val id = allocCam() ?: return
            be.down(id, cx, cy); cam[el.id] = Cam(id, cx, cy)
            return
        }
        be.move(st.id, st.x, st.y)
        camIdle[el.id]?.let { h.removeCallbacks(it) }
        val idle = Runnable { cam.remove(el.id)?.let { c -> be.up(c.id); release(c.id) } }
        camIdle[el.id] = idle
        h.postDelayed(idle, 120)                          // hareket durunca parmağı kaldır
    }

    private fun releaseCameras() {
        val be = backendProvider()
        cam.values.forEach { be?.up(it.id); release(it.id) }
        cam.clear()
    }

    /** Sağ analog çubukla kamera döndürme için periyodik tick. */
    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            stepJoysticks()
            if (rx != 0f || ry != 0f) {
                for (el in profile.elements) if (el.type == ElementType.CAMERA) {
                    val f = SPEED * DT * el.sensitivity * adsFactor(el)
                    cameraMove(el, rx * f, ry * f)
                }
            }
            h.postDelayed(this, 16)
        }
    }

    // ------------------------------------------------------------------ Aimlock / Shiftlock
    fun toggleLock() {
        locked = !locked
        if (!locked) releaseCameras()
        onLockChanged?.invoke(locked)
        notifyCursor()
    }

    // ------------------------------------------------------------------ fare (pointer capture)
    private fun setMouseButton(mask: Int, down: Boolean) {
        val name = when (mask) {
            MotionEvent.BUTTON_PRIMARY -> "M:L"
            MotionEvent.BUTTON_SECONDARY -> "M:R"
            MotionEvent.BUTTON_TERTIARY -> "M:M"
            else -> return
        }
        val was = (lastButtons and mask) != 0
        if (down == was) return                       // durum değişmediyse hiçbir şey yapma
        lastButtons = if (down) lastButtons or mask else lastButtons and mask.inv()
        val consumed = onBinding(name, down)
        // Hiçbir eleman bu fare tuşuna bağlı değilse sol tık, imlecin altına DOKUNUŞ olur
        if (name == "M:L") {
            if (down) { if (!consumed && !locked && cursorEnabled) { clickThrough = true; cursorTouch(true) } }
            else if (clickThrough) { clickThrough = false; cursorTouch(false) }
        }
    }

    private fun syncMouseButtons(bs: Int) {
        for (mask in intArrayOf(MotionEvent.BUTTON_PRIMARY, MotionEvent.BUTTON_SECONDARY, MotionEvent.BUTTON_TERTIARY))
            setMouseButton(mask, (bs and mask) != 0)
    }

    /**
     * Fare (Pointer Capture). İKİ AYRI İŞ, birbirine karışmaz:
     *  - tuşlar: sadece BUTTON_PRESS/RELEASE ve DOWN/UP olaylarında değişir
     *  - hareket: sadece kamerayı kaydırır; basılı tuşlara / dokunuşlara DOKUNMAZ
     */
    fun onCapturedMouse(ev: MotionEvent): Boolean {
        if (!running) return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_BUTTON_PRESS -> setMouseButton(ev.actionButton, true)
            MotionEvent.ACTION_BUTTON_RELEASE -> setMouseButton(ev.actionButton, false)
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_UP -> syncMouseButtons(ev.buttonState)
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_HOVER_MOVE -> {
                val relative = (ev.source and InputDevice.SOURCE_MOUSE_RELATIVE) != 0 ||
                    (ev.source and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE
                if (relative) {
                    var dx = ev.x; var dy = ev.y
                    for (i in 0 until ev.historySize) { dx += ev.getHistoricalX(i); dy += ev.getHistoricalY(i) }
                    if (dx != 0f || dy != 0f) {
                        if (locked) {
                            for (el in profile.elements) if (el.type == ElementType.CAMERA) {
                                val f = el.sensitivity * adsFactor(el)
                                cameraMove(el, dx * f, dy * f)
                            }
                        } else if (cursorEnabled) {
                            moveCursor(dx, dy)
                        }
                    }
                }
            }
            else -> {}
        }
        return true
    }

    // ------------------------------------------------------------------ gamepad eksenleri
    private fun dz(v: Float) = if (abs(v) < 0.12f) 0f else v

    fun onGenericMotion(ev: MotionEvent): Boolean {
        if (!running) return false
        val joystick = (ev.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        val mouse = (ev.source and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE ||
            (ev.source and InputDevice.SOURCE_MOUSE_RELATIVE) != 0
        if (!joystick || mouse || ev.action != MotionEvent.ACTION_MOVE) return false

        lx = dz(ev.getAxisValue(MotionEvent.AXIS_X)); ly = dz(ev.getAxisValue(MotionEvent.AXIS_Y))
        val zx = dz(ev.getAxisValue(MotionEvent.AXIS_Z)); val zy = dz(ev.getAxisValue(MotionEvent.AXIS_RZ))
        rx = if (zx != 0f || zy != 0f) zx else dz(ev.getAxisValue(MotionEvent.AXIS_RX))
        ry = if (zx != 0f || zy != 0f) zy else dz(ev.getAxisValue(MotionEvent.AXIS_RY))

        val lt = maxOf(ev.getAxisValue(MotionEvent.AXIS_LTRIGGER), ev.getAxisValue(MotionEvent.AXIS_BRAKE))
        val rt = maxOf(ev.getAxisValue(MotionEvent.AXIS_RTRIGGER), ev.getAxisValue(MotionEvent.AXIS_GAS))
        val hx = ev.getAxisValue(MotionEvent.AXIS_HAT_X); val hy = ev.getAxisValue(MotionEvent.AXIS_HAT_Y)
        synthKey(KeyEvent.KEYCODE_BUTTON_L2, lt > 0.5f)
        synthKey(KeyEvent.KEYCODE_BUTTON_R2, rt > 0.5f)
        synthKey(KeyEvent.KEYCODE_DPAD_LEFT, hx < -0.5f)
        synthKey(KeyEvent.KEYCODE_DPAD_RIGHT, hx > 0.5f)
        synthKey(KeyEvent.KEYCODE_DPAD_UP, hy < -0.5f)
        synthKey(KeyEvent.KEYCODE_DPAD_DOWN, hy > 0.5f)

        for (el in profile.elements) if (el.type == ElementType.JOYSTICK) when (el.stick) {
            StickSource.LEFT_STICK -> updateJoystick(el, lx, ly)
            StickSource.RIGHT_STICK -> updateJoystick(el, rx, ry)
            else -> {}
        }
        return true
    }

    private fun synthKey(code: Int, down: Boolean) {
        if (down == synth.contains(code)) return
        if (down) synth.add(code) else synth.remove(code)
        keyCode(code, down)
    }

    // ------------------------------------------------------------------ makro (sıralı / eşzamanlı) ve swipe
    private fun startMacro(el: MappingElement) {
        if (el.steps.isEmpty()) return
        val t = Any(); tokens[el.id] = t
        later(el.delayMs) { runMacro(el, 0, t) }
    }

    private fun runMacro(el: MappingElement, i: Int, token: Any) {
        if (tokens[el.id] !== token) return
        if (i >= el.steps.size) {
            // loop: tuş(lar) basılı olduğu sürece başa dön
            if (el.loop && active.contains(el.id)) h.postDelayed({ runMacro(el, 0, token) }, 100)
            else tokens.remove(el.id)
            return
        }
        val s = el.steps[i]
        when (s.kind) {
            "TAP" -> tap(s.x * screenW, s.y * screenH, s.durationMs)
            "SWIPE" -> animateSwipe(s.x * screenW, s.y * screenH, s.x2 * screenW, s.y2 * screenH, s.durationMs)
            else -> {}   // WAIT
        }
        // parallel: tüm adımlar aynı anda; sıralı: adım süresi + adımlar arası gecikme
        val delay = if (el.parallel) 0L else s.durationMs + el.gapMs
        if (delay == 0L) runMacro(el, i + 1, token) else h.postDelayed({ runMacro(el, i + 1, token) }, delay)
    }

    private fun tap(x: Float, y: Float, ms: Long) {
        val be = backendProvider() ?: return
        val id = alloc() ?: return
        be.down(id, x, y)
        h.postDelayed({ be.up(id); release(id) }, ms.coerceAtLeast(10))
    }

    private fun animateSwipe(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long) {
        val be = backendProvider() ?: return
        val id = alloc() ?: return
        be.down(id, x1, y1)
        val t0 = SystemClock.uptimeMillis()
        val step = object : Runnable {
            override fun run() {
                val f = ((SystemClock.uptimeMillis() - t0).toFloat() / dur.coerceAtLeast(1)).coerceAtMost(1f)
                be.move(id, x1 + (x2 - x1) * f, y1 + (y2 - y1) * f)
                if (f < 1f) h.postDelayed(this, 16) else { be.up(id); release(id) }
            }
        }
        step.run()
    }

    companion object {
        private const val CAM_BASE = 7           // 0..6 klavye/gamepad, 7..9 fare-kamera
        private const val FOCUS_GRACE = 1500L    // odak kaybı toleransı (ms)
        private const val SPEED = 900f    // gamepad kamera hızı (px/sn)
        private const val DT = 0.016f
    }
}
