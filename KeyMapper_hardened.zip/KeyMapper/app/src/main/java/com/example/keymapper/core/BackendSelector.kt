package com.example.keymapper.core

import com.example.keymapper.adb.InjectorClient
import com.example.keymapper.service.KeyMapperAccessibilityService

/**
 * Enjektör seçim mantığı (ayar gerekmez, otomatik):
 *   ADB enjektörü bağlı                 -> ADB
 *   ADB yok + Erişilebilirlik açık      -> Erişilebilirlik (dispatchGesture)
 *   ikisi de yok                        -> NONE (kullanıcıya uyarı)
 * Her dokunuşta yeniden değerlendirilir; ADB koparsa otomatik Erişilebilirliğe düşer.
 */
object BackendSelector {
    enum class Mode { ADB, ACCESSIBILITY, NONE }

    fun mode(): Mode = when {
        InjectorClient.isActive -> Mode.ADB
        KeyMapperAccessibilityService.instance?.backend != null -> Mode.ACCESSIBILITY
        else -> Mode.NONE
    }

    fun backend(): TouchBackend? = when (mode()) {
        Mode.ADB -> InjectorClient
        Mode.ACCESSIBILITY -> KeyMapperAccessibilityService.instance?.backend
        Mode.NONE -> null
    }

    fun label(m: Mode = mode()): String = when (m) {
        Mode.ADB -> "ADB enjektörü"
        Mode.ACCESSIBILITY -> "Erişilebilirlik (dispatchGesture)"
        Mode.NONE -> "YOK"
    }
}
