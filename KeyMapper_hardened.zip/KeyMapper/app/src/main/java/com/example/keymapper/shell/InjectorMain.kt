package com.example.keymapper.shell

import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.OutputStream
import java.lang.reflect.Method
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.system.exitProcess

/**
 * SHELL (uid 2000) kullanıcısıyla `app_process` içinde çalışır (adb shell ile başlatılır).
 * 127.0.0.1:<port> üzerinde dinler; istemciden gelen dokunuş komutlarını gerçek çoklu-dokunuş
 * MotionEvent'lerine çevirip InputManager.injectInputEvent ile sisteme enjekte eder.
 * Hatalar stderr'e yazılır (başlatıcı bunu /data/local/tmp/km_injector.log'a yönlendirir).
 */
object InjectorMain {
    private var target: Any? = null
    private var method: Method? = null

    private val ids = ArrayList<Int>()
    private val pos = HashMap<Int, FloatArray>()
    private var downTime = 0L

    @JvmStatic
    fun main(args: Array<String>) {
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            System.err.println("km_injector: ÇÖKTÜ: $e")
            e.printStackTrace()
            exitProcess(2)
        }
        val port = args[0].toInt()
        val token = args[1].toLong()
        initInjection()
        System.err.println("km_injector: port=$port enjeksiyon=${if (method != null) "HAZIR" else "YOK"}")

        val ss = ServerSocket()
        ss.reuseAddress = true
        try {
            ss.bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), port))
        } catch (e: Exception) {
            System.err.println("km_injector: port dolu: ${e.message}")
            exitProcess(1)
        }
        while (true) {
            val s = try { ss.accept() } catch (e: Exception) { continue }
            try { serve(s, token) } catch (e: Throwable) {
                System.err.println("km_injector: bağlantı bitti: ${e.javaClass.simpleName} ${e.message}")
            } finally {
                releaseAll()                 // bağlantı koparsa takılı parmak kalmasın
                try { s.close() } catch (_: Exception) {}
            }
        }
    }

    private fun initInjection() {
        // scrcpy gibi: önce InputManager (Android 14+ dahil), olmazsa InputManagerGlobal
        for (cn in listOf("android.hardware.input.InputManager", "android.hardware.input.InputManagerGlobal")) {
            try {
                val c = Class.forName(cn)
                val inst = c.getMethod("getInstance").invoke(null)
                val m = c.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
                if (inst != null) { target = inst; method = m; return }
            } catch (e: Throwable) {
                System.err.println("km_injector: $cn kullanılamadı: ${e.javaClass.simpleName} ${e.message}")
            }
        }
    }

    private fun status(): Int = if (method != null) 1 else 2

    private fun serve(s: Socket, token: Long) {
        s.tcpNoDelay = true
        val input = DataInputStream(BufferedInputStream(s.getInputStream()))
        val output: OutputStream = s.getOutputStream()
        if (input.readLong() != token) return          // yetkisiz istemci
        output.write(status()); output.flush()
        while (true) {
            when (input.readUnsignedByte()) {
                0 -> { val id = input.readInt(); down(id, input.readFloat(), input.readFloat()) }
                1 -> { val id = input.readInt(); move(id, input.readFloat(), input.readFloat()) }
                2 -> up(input.readInt())
                3 -> releaseAll()
                4 -> { output.write(status()); output.flush() }      // ping
                9 -> { releaseAll(); exitProcess(0) }
            }
        }
    }

    // ------------------------------------------------------------------ çoklu dokunuş durumu
    private fun send(action: Int) {
        val n = ids.size
        if (n == 0) return
        val props = Array(n) { i ->
            MotionEvent.PointerProperties().apply { id = ids[i]; toolType = MotionEvent.TOOL_TYPE_FINGER }
        }
        val coords = Array(n) { i ->
            val p = pos[ids[i]]!!
            MotionEvent.PointerCoords().apply { x = p[0]; y = p[1]; pressure = 1f; size = 1f }
        }
        val ev = MotionEvent.obtain(
            downTime, SystemClock.uptimeMillis(), action, n, props, coords,
            0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        try { method?.invoke(target, ev, 0) } catch (e: Throwable) {
            System.err.println("km_injector: enjeksiyon hatası: ${e.cause ?: e}")
        } finally { ev.recycle() }   // 0 = ASYNC
    }

    private fun down(id: Int, x: Float, y: Float) {
        if (ids.contains(id)) return
        ids.add(id); pos[id] = floatArrayOf(x, y)
        if (ids.size == 1) {
            downTime = SystemClock.uptimeMillis(); send(MotionEvent.ACTION_DOWN)
        } else {
            send(MotionEvent.ACTION_POINTER_DOWN or (ids.indexOf(id) shl MotionEvent.ACTION_POINTER_INDEX_SHIFT))
        }
    }

    private fun move(id: Int, x: Float, y: Float) {
        val p = pos[id] ?: return
        p[0] = x; p[1] = y
        send(MotionEvent.ACTION_MOVE)
    }

    private fun up(id: Int) {
        val idx = ids.indexOf(id)
        if (idx < 0) return
        if (ids.size == 1) send(MotionEvent.ACTION_UP)
        else send(MotionEvent.ACTION_POINTER_UP or (idx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT))
        ids.removeAt(idx); pos.remove(id)
    }

    private fun releaseAll() {
        while (ids.isNotEmpty()) up(ids.last())
    }
}
