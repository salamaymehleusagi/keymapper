package com.example.keymapper.security

import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import android.os.Debug
import android.util.Base64
import com.example.keymapper.BuildConfig
import java.security.MessageDigest

/**
 * Basit "anti-tamper" kontrolleri.
 *
 * Bunlar APK'yı decompile EDİLEMEZ yapmaz (hiçbir şey yapmaz — Android bir
 * noktada kodu cihazda çalıştırmak zorunda). Amaç şu: biri APK'yı alıp
 * tersine mühendislikle değiştirip (ADB token kontrolünü kaldırma, enjektör
 * portunu açık bırakma, reklam/malware ekleme vb.) kendi imzasıyla yeniden
 * paketlerse, uygulama bunu RELEASE build'de fark edip kendini kapatsın.
 *
 * KURULUM: Kendi release keystore'unla imzaladıktan sonra aşağıdaki
 * EXPECTED_SIGNATURE_SHA256 değerini kendi sertifikanın SHA-256 özetiyle
 * doldur:
 *   keytool -list -v -keystore senin.keystore -alias senin-alias
 * (çıktıdaki "SHA256:" satırını al, ":" işaretlerini kaldır, küçük harfe çevir)
 *
 * Boş bırakılırsa imza kontrolü ATLANIR (debug akışını bozmamak için) —
 * yani varsayılan olarak hiçbir koruma AKTİF DEĞİL, doldurman gerekiyor.
 */
object SecurityGuard {

    /** Küçük harf, ":" içermeyen hex SHA-256. Boş = kontrol atlanır. */
    private const val EXPECTED_SIGNATURE_SHA256 = ""

    /**
     * MainActivity/Application.onCreate() başında çağır. Sorun bulursa
     * `true` döner ve çağıran taraf uygulamayı kapatmalı (ör. finish() +
     * exitProcess(0)). Debug build'de hiçbir zaman true dönmez.
     */
    fun shouldAbort(ctx: Context): Boolean {
        if (BuildConfig.DEBUG) return false
        return isDebuggerAttached() || isResigned(ctx)
    }

    private fun isDebuggerAttached(): Boolean =
        Debug.isDebuggerConnected() || Debug.waitingForDebugger()

    /** APK'nın imza sertifikası, build'de gömülü beklenenle eşleşiyor mu? */
    private fun isResigned(ctx: Context): Boolean {
        if (EXPECTED_SIGNATURE_SHA256.isBlank()) return false // yapılandırılmadı -> atla
        val actual = currentSignatureSha256(ctx) ?: return true // alınamadıysa güvenli taraf: durdur
        return !actual.equals(EXPECTED_SIGNATURE_SHA256, ignoreCase = true)
    }

    private fun currentSignatureSha256(ctx: Context): String? = try {
        val pm = ctx.packageManager
        val sig: Signature = if (Build.VERSION.SDK_INT >= 28) {
            val info = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            val signers = info.signingInfo?.apkContentsSigners
            if (signers.isNullOrEmpty()) return null
            signers[0]
        } else {
            @Suppress("DEPRECATION")
            val info = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES)
            @Suppress("DEPRECATION")
            info.signatures?.firstOrNull() ?: return null
        }
        val digest = MessageDigest.getInstance("SHA-256").digest(sig.toByteArray())
        digest.joinToString("") { "%02x".format(it) }
    } catch (e: Exception) {
        null
    }

    /** Debug/analiz amaçlı: mevcut imzanın özetini loglamak için (kurulum sırasında kullan). */
    fun currentSignatureForSetup(ctx: Context): String =
        currentSignatureSha256(ctx) ?: "alınamadı"
}
