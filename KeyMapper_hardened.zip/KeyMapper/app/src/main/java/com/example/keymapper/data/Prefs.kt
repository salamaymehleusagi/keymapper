package com.example.keymapper.data

import android.content.Context
import java.security.SecureRandom

/** Basit ayar deposu. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("km", Context.MODE_PRIVATE)

    /** "ADB" (yerleşik kablosuz ADB enjektörü) veya "ACCESSIBILITY" */
    fun backend(c: Context): String = sp(c).getString("backend", "ADB")!!
    fun setBackend(c: Context, v: String) = sp(c).edit().putString("backend", v).apply()

    fun activeProfile(c: Context): String = sp(c).getString("active", "Default")!!
    fun setActiveProfile(c: Context, v: String) = sp(c).edit().putString("active", v).apply()

    fun pkgProfile(c: Context, pkg: String): String? = sp(c).getString("pkg_$pkg", null)
    fun setPkgProfile(c: Context, pkg: String, name: String) =
        sp(c).edit().putString("pkg_$pkg", name).apply()

    /** Enjektör sunucusunun yerel TCP portu. */
    fun port(c: Context): Int = sp(c).getInt("inj_port", 38999)

    /** Enjektöre başka uygulamaların bağlanmasını engelleyen gizli anahtar (ilk kullanımda üretilir). */
    @Synchronized
    fun token(c: Context): Long {
        val s = sp(c)
        if (!s.contains("inj_token")) s.edit().putLong("inj_token", SecureRandom().nextLong()).apply()
        return s.getLong("inj_token", 0L)
    }

    fun connPort(c: Context): Int = sp(c).getInt("conn_port", -1)
    fun setConn(c: Context, host: String, port: Int) =
        sp(c).edit().putString("host", host).putInt("conn_port", port).apply()

    /**
     * Oyun modunda fareyi YAKALA (Pointer Capture). Varsayılan AÇIK.
     * Kapalıysa fare imleci oyunun üstünde gezer ve her fare hareketi sistemde gerçek fare olayı üretir;
     * bu olaylar enjekte edilen dokunuşları (joystick/ateş) keser.
     */
    fun captureMouse(c: Context): Boolean = sp(c).getBoolean("capture_mouse", true)
    fun setCaptureMouse(c: Context, v: Boolean) = sp(c).edit().putBoolean("capture_mouse", v).apply()

    /** Sanal fare imleci: yakalanan fare yerine ekranda kendi imlecimiz çizilir (tıkla = dokun). */
    fun virtualCursor(c: Context): Boolean = sp(c).getBoolean("v_cursor", true)
    fun setVirtualCursor(c: Context, v: Boolean) = sp(c).edit().putBoolean("v_cursor", v).apply()
    fun cursorSpeed(c: Context): Float = sp(c).getFloat("c_speed", 1.2f)
    fun setCursorSpeed(c: Context, v: Float) = sp(c).edit().putFloat("c_speed", v).apply()

    /** Eklenen oyunlar (paket adları, satır satır). */
    fun games(c: Context): List<String> =
        (sp(c).getString("games", "") ?: "").split("\n").filter { it.isNotBlank() }
    fun addGame(c: Context, pkg: String) {
        val l = games(c).toMutableList()
        if (!l.contains(pkg)) { l.add(pkg); sp(c).edit().putString("games", l.joinToString("\n")).apply() }
    }
    fun removeGame(c: Context, pkg: String) =
        sp(c).edit().putString("games", games(c).filter { it != pkg }.joinToString("\n")).apply()

    fun lastHost(c: Context): String = sp(c).getString("host", "127.0.0.1")!!
    fun setLastHost(c: Context, v: String) = sp(c).edit().putString("host", v).apply()
}
