package com.example.keymapper.adb

import android.content.Context
import android.os.Build
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import java.io.ByteArrayOutputStream
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.Signature
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * libadb-android üzerine ADB bağlantı yöneticisi.
 * RSA anahtarı + sertifika dosyada saklanır: eşleme (adb pair) bir kez yapılır ve kalıcı olur.
 * Sertifika, dış kütüphane gerektirmeden elle DER olarak üretilir (self-signed, SHA256withRSA).
 */
class KeyMapperAdb private constructor(ctx: Context) : AbsAdbConnectionManager() {

    private lateinit var pKey: PrivateKey
    private lateinit var pCert: Certificate

    init {
        setApi(Build.VERSION.SDK_INT)
        val keyFile = File(ctx.filesDir, "adb_key.pk8")
        val certFile = File(ctx.filesDir, "adb_cert.der")
        var pk: PrivateKey? = null
        var cert: Certificate? = null
        if (keyFile.exists() && certFile.exists()) {
            try {
                pk = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(keyFile.readBytes()))
                cert = certFile.inputStream().use { CertificateFactory.getInstance("X.509").generateCertificate(it) }
            } catch (_: Exception) { pk = null; cert = null }
        }
        if (pk == null || cert == null) {
            val kpg = KeyPairGenerator.getInstance("RSA")
            kpg.initialize(2048)
            val kp = kpg.generateKeyPair()
            val der = buildSelfSignedCert(kp.private, kp.public.encoded)
            val newCert = CertificateFactory.getInstance("X.509").generateCertificate(der.inputStream())
            keyFile.writeBytes(kp.private.encoded)
            certFile.writeBytes(der)
            pk = kp.private
            cert = newCert
        }
        pKey = pk!!
        pCert = cert!!
    }

    override fun getPrivateKey(): PrivateKey = pKey
    override fun getCertificate(): Certificate = pCert
    override fun getDeviceName(): String = "KeyMapper"

    // ------------------------------------------------------------------ minimal DER yardımcıları
    private fun der(tag: Int, content: ByteArray): ByteArray {
        val len = content.size
        val lenBytes = when {
            len < 128 -> byteArrayOf(len.toByte())
            len < 256 -> byteArrayOf(0x81.toByte(), len.toByte())
            else -> byteArrayOf(0x82.toByte(), (len shr 8).toByte(), len.toByte())
        }
        val out = ByteArrayOutputStream()
        out.write(tag); out.write(lenBytes); out.write(content)
        return out.toByteArray()
    }

    private fun cat(vararg parts: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        parts.forEach { out.write(it) }
        return out.toByteArray()
    }

    private fun utcTime(d: Date): ByteArray {
        val f = SimpleDateFormat("yyMMddHHmmss'Z'", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return der(0x17, f.format(d).toByteArray(Charsets.US_ASCII))
    }

    /** X.509 v3, self-signed, sha256WithRSAEncryption, CN=KeyMapper, 10 yıl geçerli. */
    private fun buildSelfSignedCert(priv: PrivateKey, spki: ByteArray): ByteArray {
        // AlgorithmIdentifier { sha256WithRSAEncryption, NULL }
        val sigAlg = byteArrayOf(
            0x30, 0x0D, 0x06, 0x09, 0x2A, 0x86.toByte(), 0x48, 0x86.toByte(),
            0xF7.toByte(), 0x0D, 0x01, 0x01, 0x0B, 0x05, 0x00
        )
        val version = der(0xA0, der(0x02, byteArrayOf(0x02)))                       // [0] v3
        val serial = der(0x02, BigInteger(63, SecureRandom()).add(BigInteger.ONE).toByteArray())
        val cn = der(0x30, der(0x31, der(0x30, cat(
            der(0x06, byteArrayOf(0x55, 0x04, 0x03)),                                  // OID 2.5.4.3 (CN)
            der(0x0C, "KeyMapper".toByteArray(Charsets.UTF_8))                         // UTF8String
        ))))
        val now = Date()
        val until = Date(now.time + 10L * 365 * 24 * 3600 * 1000)
        val validity = der(0x30, cat(utcTime(now), utcTime(until)))

        val tbs = der(0x30, cat(version, serial, sigAlg, cn, validity, cn, spki))

        val sig = Signature.getInstance("SHA256withRSA")
        sig.initSign(priv)
        sig.update(tbs)
        val signature = sig.sign()
        val sigBits = der(0x03, cat(byteArrayOf(0x00), signature))
        return der(0x30, cat(tbs, sigAlg, sigBits))
    }

    companion object {
        @Volatile private var inst: KeyMapperAdb? = null
        fun get(ctx: Context): KeyMapperAdb =
            inst ?: synchronized(this) {
                inst ?: KeyMapperAdb(ctx.applicationContext).also { inst = it }
            }
    }
}
